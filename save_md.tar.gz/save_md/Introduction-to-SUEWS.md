### Topic: Introduction To SUEWS

***
### How long will this take
XX minutes

### Expected knowledge/activity before this
* UMEP installed
* Introduction to GIS

### Meteorology Background
* Introduction to urban surface energy balance 
* Introduction to urban water balance
* Scale in the urban environment

### Activity
* SUEWS manual link - this provides details of the SUEWS model
* SUEWS paper link - overview paper

* [Tutorial link](h)
  * Data for tutorial link

* [What to do if you are stuck](Stuck?)


## Topic: A First QGIS and UMEP activity

***

### Assumed prior knowledge
1. QGIS installed
1. UMEP installed

### GIS Background
* No prior knowledge needed

### Meteorology Background
* No prior knowledge

### Introduction to Topic
* Simple example on how to create shadow maps using QGIS and UMEP.
					
### Order to do things
* Tutorial Link

* Video link

* Data link	
	- none needed			
	
				
### What topics should be covered next?
*  Basics on the QGIS graphical user interface, UMEP and spatial data.

Link:
link to  next topic and why
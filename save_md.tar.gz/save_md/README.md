# archived MD files from wiki

- All files here are original wiki pages.
- These files have been converted into `rst` for the workshop site and placed in `source` folder.
  - The conversion is done by `md2rst.sh` in this folder.